'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/router';
import Cookies from 'js-cookie';
import { supabase } from '@/lib/supabaseClient';

export default function Callback() {
  const router = useRouter();

  useEffect(() => {
    const handleOAuthCallback = async () => {
      const hash = window.location.hash;
      const params = new URLSearchParams(hash.substring(1));

      const access_token = params.get('access_token');
      const refresh_token = params.get('refresh_token');

      if (!access_token || !refresh_token) {
        router.replace('/login');
        return;
      }

      // ✅ أخبر Supabase بتفعيل الجلسة
      const { error: sessionError } = await supabase.auth.setSession({
        access_token,
        refresh_token,
      });

      if (sessionError) {
        console.error('Failed to set session:', sessionError);
        router.replace('/login');
        return;
      }

      // ✅ احصل على المستخدم الحالي من Supabase
      const { data: { user }, error } = await supabase.auth.getUser();

      if (!user || error) {
        console.error('Failed to fetch user:', error);
        router.replace('/login');
        return;
      }

      const userData = {
        email: user.email,
        name: user.user_metadata?.full_name || user.email,
        avatar: user.user_metadata?.avatar_url || '',
      };

      // ✅ خزّن الكوكيز
      Cookies.set('token', access_token, { path: '/', expires: 1 });
      Cookies.set('user', JSON.stringify(userData), { path: '/', expires: 1 });

      // ✅ خزّن المستخدم في جدولك المخصص "Data"
      await supabase.from('Data').upsert({
        email: userData.email,
        name: userData.name,
        password: null,
      }, {
        onConflict: ['email'],
      });

      // ✅ توجه للداشبورد
      router.replace('/dashboard');
    };

    handleOAuthCallback();
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center text-white text-lg">
      Finishing Google login...
    </div>
  );
}
